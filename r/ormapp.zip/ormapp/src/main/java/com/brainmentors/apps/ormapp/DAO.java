package com.brainmentors.apps.ormapp;

import org.hibernate.Session;
import org.hibernate.Transaction;

import com.brainmentors.apps.ormapp.utils.Config;
import com.brainmentors.apps.ormapp.utils.Course;
import com.brainmentors.apps.ormapp.utils.Student;



public class DAO {

	
	public void save(Customer customer) {
		Session session = Config.getSessionFactory().openSession();
		Transaction trans = session.beginTransaction();
		session.save(customer);
		trans.commit();
		session.close();
		
		System.out.println("Customer Added..");
	}
	
	public void saveStudent(Student student, Course course) {
		Session session = Config.getSessionFactory().openSession();
		Transaction trans = session.beginTransaction();
		session.save(student);
		session.save(course);
		trans.commit();
		session.close();
		
		System.out.println("Student Added..");
	}
}
