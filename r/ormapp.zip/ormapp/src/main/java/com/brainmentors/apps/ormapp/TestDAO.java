package com.brainmentors.apps.ormapp;

import com.brainmentors.apps.ormapp.utils.Course;
import com.brainmentors.apps.ormapp.utils.Student;


public class TestDAO {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
//		DAO dao = new DAO();
//		Customer customer = new Customer();
//		customer.setId(1001);
//		customer.setName("Abcd");
//		customer.setBalance(99999);
//		dao.save(customer);
		DAO dao = new DAO();
		Student student = new Student();
		student.setName("Ram");
		student.setAge(21);
		Course course = new Course();
		course.setName("Java");
		course.setDuration(20);
		student.setCourse(course);
		//course.setStudent(student);
		dao.saveStudent(student, course);

	}

}
